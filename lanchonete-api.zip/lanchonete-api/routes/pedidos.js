const express = require('express');
const router = express.Router();

// Mock data
let pedidos = [
    { id: 1, cliente: 'Gabriel', produtos: [1, 2], total: 19.5 },
    { id: 2, cliente: 'Ana', produtos: [2], total: 7.0 },
];

// Listar todos os pedidos
router.get('/', (req, res) => {
    res.json(pedidos);
});

// Buscar pedido por ID
router.get('/:id', (req, res) => {
    const pedido = pedidos.find(p => p.id == req.params.id);
    if (pedido) res.json(pedido);
    else res.status(404).json({ message: 'Pedido não encontrado' });
});

// Criar novo pedido
router.post('/', (req, res) => {
    const novoPedido = {
        id: pedidos.length + 1,
        cliente: req.body.cliente,
        produtos: req.body.produtos,
        total: req.body.total
    };
    pedidos.push(novoPedido);
    res.status(201).json(novoPedido);
});

// Atualizar pedido
router.put('/:id', (req, res) => {
    const pedido = pedidos.find(p => p.id == req.params.id);
    if (pedido) {
        pedido.cliente = req.body.cliente;
        pedido.produtos = req.body.produtos;
        pedido.total = req.body.total;
        res.json(pedido);
    } else {
        res.status(404).json({ message: 'Pedido não encontrado' });
    }
});

// Deletar pedido
router.delete('/:id', (req, res) => {
    pedidos = pedidos.filter(p => p.id != req.params.id);
    res.json({ message: 'Pedido deletado com sucesso' });
});

module.exports = router;
