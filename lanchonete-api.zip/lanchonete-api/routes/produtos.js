const express = require('express');
const router = express.Router();

// Mock data
let produtos = [
    { id: 1, nome: 'Hambúrguer', preco: 12.5 },
    { id: 2, nome: 'Batata Frita', preco: 7.0 },
];

// Listar todos os produtos
router.get('/', (req, res) => {
    res.json(produtos);
});

// Buscar produto por ID
router.get('/:id', (req, res) => {
    const produto = produtos.find(p => p.id == req.params.id);
    if (produto) res.json(produto);
    else res.status(404).json({ message: 'Produto não encontrado' });
});

// Criar novo produto
router.post('/', (req, res) => {
    const novoProduto = {
        id: produtos.length + 1,
        nome: req.body.nome,
        preco: req.body.preco
    };
    produtos.push(novoProduto);
    res.status(201).json(novoProduto);
});

// Atualizar produto
router.put('/:id', (req, res) => {
    const produto = produtos.find(p => p.id == req.params.id);
    if (produto) {
        produto.nome = req.body.nome;
        produto.preco = req.body.preco;
        res.json(produto);
    } else {
        res.status(404).json({ message: 'Produto não encontrado' });
    }
});

// Deletar produto
router.delete('/:id', (req, res) => {
    produtos = produtos.filter(p => p.id != req.params.id);
    res.json({ message: 'Produto deletado com sucesso' });
});

module.exports = router;
