const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

// Importar rotas
const produtosRoutes = require('./routes/produtos');
const pedidosRoutes = require('./routes/pedidos');

// Usar rotas
app.use('/produtos', produtosRoutes);
app.use('/pedidos', pedidosRoutes);

// Rota principal
app.get('/', (req, res) => {
    res.send('API Lanchonete funcionando!');
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
