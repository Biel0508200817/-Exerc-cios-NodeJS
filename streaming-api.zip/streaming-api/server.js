const express = require('express');
const app = express();
const PORT = 3000;

app.use(express.json());

// Importar rotas
const usuariosRoutes = require('./routes/usuarios');
const videosRoutes = require('./routes/videos');
const categoriasRoutes = require('./routes/categorias');
const assinaturasRoutes = require('./routes/assinaturas');

// Usar rotas
app.use('/usuarios', usuariosRoutes);
app.use('/videos', videosRoutes);
app.use('/categorias', categoriasRoutes);
app.use('/assinaturas', assinaturasRoutes);

// Rota principal
app.get('/', (req, res) => {
    res.send('API Plataforma de Streaming de Vídeos funcionando!');
});

app.listen(PORT, () => {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
