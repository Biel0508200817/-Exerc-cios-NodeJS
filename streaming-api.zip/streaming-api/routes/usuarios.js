const express = require('express');
const router = express.Router();

let usuarios = [
    { id: 1, nome: 'Gabriel', email: 'gabriel@email.com' },
    { id: 2, nome: 'Ana', email: 'ana@email.com' },
];

// Listar todos os usuários
router.get('/', (req, res) => {
    res.json(usuarios);
});

// Buscar usuário por ID
router.get('/:id', (req, res) => {
    const usuario = usuarios.find(u => u.id == req.params.id);
    if (usuario) res.json(usuario);
    else res.status(404).json({ message: 'Usuário não encontrado' });
});

// Criar novo usuário
router.post('/', (req, res) => {
    const novoUsuario = {
        id: usuarios.length + 1,
        nome: req.body.nome,
        email: req.body.email
    };
    usuarios.push(novoUsuario);
    res.status(201).json(novoUsuario);
});

// Atualizar usuário
router.put('/:id', (req, res) => {
    const usuario = usuarios.find(u => u.id == req.params.id);
    if (usuario) {
        usuario.nome = req.body.nome;
        usuario.email = req.body.email;
        res.json(usuario);
    } else {
        res.status(404).json({ message: 'Usuário não encontrado' });
    }
});

// Deletar usuário
router.delete('/:id', (req, res) => {
    usuarios = usuarios.filter(u => u.id != req.params.id);
    res.json({ message: 'Usuário deletado com sucesso' });
});

module.exports = router;
