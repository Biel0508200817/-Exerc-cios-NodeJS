const express = require('express');
const router = express.Router();

let videos = [
    { id: 1, titulo: 'Video 1', descricao: 'Descrição do Video 1', categoriaId: 1 },
    { id: 2, titulo: 'Video 2', descricao: 'Descrição do Video 2', categoriaId: 2 },
];

// Listar vídeos
router.get('/', (req, res) => res.json(videos));

// Buscar por ID
router.get('/:id', (req, res) => {
    const video = videos.find(v => v.id == req.params.id);
    if (video) res.json(video);
    else res.status(404).json({ message: 'Vídeo não encontrado' });
});

// Criar vídeo
router.post('/', (req, res) => {
    const novoVideo = {
        id: videos.length + 1,
        titulo: req.body.titulo,
        descricao: req.body.descricao,
        categoriaId: req.body.categoriaId
    };
    videos.push(novoVideo);
    res.status(201).json(novoVideo);
});

// Atualizar vídeo
router.put('/:id', (req, res) => {
    const video = videos.find(v => v.id == req.params.id);
    if (video) {
        video.titulo = req.body.titulo;
        video.descricao = req.body.descricao;
        video.categoriaId = req.body.categoriaId;
        res.json(video);
    } else {
        res.status(404).json({ message: 'Vídeo não encontrado' });
    }
});

// Deletar vídeo
router.delete('/:id', (req, res) => {
    videos = videos.filter(v => v.id != req.params.id);
    res.json({ message: 'Vídeo deletado com sucesso' });
});

module.exports = router;
