const express = require('express');
const router = express.Router();

let assinaturas = [
    { id: 1, tipo: 'Básico', preco: 19.9 },
    { id: 2, tipo: 'Premium', preco: 39.9 },
];

// Listar assinaturas
router.get('/', (req, res) => res.json(assinaturas));

// Buscar por ID
router.get('/:id', (req, res) => {
    const assinatura = assinaturas.find(a => a.id == req.params.id);
    if (assinatura) res.json(assinatura);
    else res.status(404).json({ message: 'Assinatura não encontrada' });
});

// Criar assinatura
router.post('/', (req, res) => {
    const novaAssinatura = {
        id: assinaturas.length + 1,
        tipo: req.body.tipo,
        preco: req.body.preco
    };
    assinaturas.push(novaAssinatura);
    res.status(201).json(novaAssinatura);
});

// Atualizar assinatura
router.put('/:id', (req, res) => {
    const assinatura = assinaturas.find(a => a.id == req.params.id);
    if (assinatura) {
        assinatura.tipo = req.body.tipo;
        assinatura.preco = req.body.preco;
        res.json(assinatura);
    } else {
        res.status(404).json({ message: 'Assinatura não encontrada' });
    }
});

// Deletar assinatura
router.delete('/:id', (req, res) => {
    assinaturas = assinaturas.filter(a => a.id != req.params.id);
    res.json({ message: 'Assinatura deletada com sucesso' });
});

module.exports = router;
