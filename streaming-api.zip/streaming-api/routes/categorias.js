const express = require('express');
const router = express.Router();

let categorias = [
    { id: 1, nome: 'Ação' },
    { id: 2, nome: 'Comédia' },
];

// Listar categorias
router.get('/', (req, res) => res.json(categorias));

// Buscar por ID
router.get('/:id', (req, res) => {
    const categoria = categorias.find(c => c.id == req.params.id);
    if (categoria) res.json(categoria);
    else res.status(404).json({ message: 'Categoria não encontrada' });
});

// Criar categoria
router.post('/', (req, res) => {
    const novaCategoria = {
        id: categorias.length + 1,
        nome: req.body.nome
    };
    categorias.push(novaCategoria);
    res.status(201).json(novaCategoria);
});

// Atualizar categoria
router.put('/:id', (req, res) => {
    const categoria = categorias.find(c => c.id == req.params.id);
    if (categoria) {
        categoria.nome = req.body.nome;
        res.json(categoria);
    } else {
        res.status(404).json({ message: 'Categoria não encontrada' });
    }
});

// Deletar categoria
router.delete('/:id', (req, res) => {
    categorias = categorias.filter(c => c.id != req.params.id);
    res.json({ message: 'Categoria deletada com sucesso' });
});

module.exports = router;
